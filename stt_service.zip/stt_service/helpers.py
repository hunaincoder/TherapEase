"""
    This module contains helper functions for the main application.
"""
from typing import Dict, List


def parse_diarization_result(response: str) -> List[Dict[str, str]]:
    """
    Parses the diarization result from the response.
    
    Args:
        response: The response from the model.
    
    Returns:
        A list of speaker and text.
    """
    # Parse the model's response
    lines = response.strip().splitlines()
    if lines == ["None"]:
        return []
    result = []
    current_speaker = None
    current_text = None
    for line in lines:
        line = line.strip()
        if line.startswith("Speaker:"):
            current_speaker = line.replace("Speaker:", "").strip()
        elif line.startswith("Text:"):
            current_text = line.replace("Text:", "").strip()
            if current_speaker and current_text:
                result.append({"speaker": current_speaker, "text": current_text})
                current_speaker = None
                current_text = None
    return result


